import os
import argparse
import random

import wgan_div
import numpy as np
from torch.autograd import Variable
# import torch.nn.functional as F
import torch
from utils_wgan_div import *
import torch.autograd as autograd

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

cuda = True if torch.cuda.is_available() else False
Tensor = torch.cuda.FloatTensor if cuda else torch.FloatTensor

def getArgs():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_epochs", type=int, default=200, help="number of epoch of training")
    parser.add_argument("--batch_size", type=int, default=1, help="size of the batches")
    parser.add_argument("--lr", type=float, default=0.0002, help="adam: learning rate")
    parser.add_argument("--b1", type=float, default=0.5, help="adam: decay of first order momentum of gradient")
    parser.add_argument("--b2", type=float, default=0.999, help="adam: decay of first order momentum of gradient")
    parser.add_argument("--latent_dim", type=int, default=10, help="dimensionality of the latent space")
    parser.add_argument("--n_critic", type=int, default=2, help="number of training steps for discriminator per iter")
    parser.add_argument("--clip_value", type=float, default=0.01, help="lower and upper clip value for disc. weights")
    parser.add_argument("--sample_interval", type=int, default=400, help="interval between data samples")
    args = parser.parse_args()
    return args


def getData(data=[], action=2):
    if data == []:
        with open('./data/tiger4_9.txt', 'r') as f:
            readlines = f.readlines()
        for line in readlines:
            data.append([int(i) for i in line.strip()])
    source = data
    new_data = []
    for item in data:
        tmp_item = []
        for i in item:  # i= 1,1,1,0,2,0,2
            tmp_i = [0] * action
            tmp_i[i] = 1
            tmp_item.extend(tmp_i)
        new_data.append(tmp_item)
    data = torch.tensor(new_data, dtype=torch.long)
    return source, data


def train(generator, discriminator, data, args):
    k = 2
    p = 6

    # Optimizers
    optimizer_G = torch.optim.Adam(generator.parameters(), lr=args.lr, betas=(args.b1, args.b2))
    optimizer_D = torch.optim.Adam(discriminator.parameters(), lr=args.lr, betas=(args.b1, args.b2))

    for epoch in range(args.n_epochs):
        for i, x in enumerate(data):
            # Configure input
            real_seq = Variable(torch.unsqueeze(x.type(Tensor), 0), requires_grad=True)

            optimizer_D.zero_grad()

            # Sample noise as generator input
            z = Variable(Tensor(np.random.normal(0, 1, (args.batch_size, args.latent_dim))))

            # Generate a batch of data
            fake_seq = generator(z)

            # Real sample
            real_validity = discriminator(real_seq)
            # Fake sample
            fake_validity = discriminator(fake_seq)

            # Compute W-div gradient penalty
            real_grad_out = Variable(Tensor(real_seq.size(0), 1).fill_(1.0), requires_grad=False)
            real_grad = autograd.grad(real_validity, real_seq, real_grad_out, create_graph=True, retain_graph=True, only_inputs=True)[0]
            real_grad_norm = real_grad.view(real_grad.size(0), -1).pow(2).sum(1) ** (p / 2)

            fake_grad_out = Tensor(fake_seq.size(0), 1).fill_(1.0)
            fake_grad = autograd.grad(fake_validity, fake_seq, fake_grad_out, create_graph=True, retain_graph=True, only_inputs=True)[0]
            fake_grad_norm = fake_grad.view(fake_grad.size(0), -1).pow(2).sum(1) ** (p / 2)

            div_gp = torch.mean(real_grad_norm + fake_grad_norm) * k / 2

            # Adversarial loss
            d_loss = -torch.mean(real_validity) + torch.mean(fake_validity) + div_gp

            d_loss.backward()
            optimizer_D.step()

            optimizer_G.zero_grad()

            # Train the generator every n_critic steps
            if i % args.n_critic == 1:

                fake_seq = generator(z)
                # Loss measures generator's ability to fool the discriminator
                # Train on fake sample
                fake_validity = discriminator(fake_seq)
                g_loss = -torch.mean(fake_validity)

                g_loss.backward()
                optimizer_G.step()

                print("[Epoch %d/%d] [Batch %d/%d] [D loss: %f] [G loss: %f]"
                    % (epoch, args.n_epochs, i, len(data), d_loss.item(), g_loss.item()))


def inference(generator, data, args):
    output_x = []
    output_z = []
    with torch.no_grad():
        for i in range(150):
            # 生成随机数z,并把它放入到训练好的模型中用生成器生成
            z = torch.randn(args.batch_size, args.latent_dim).to(device)
            out2 = generator(z)
            output_x.append(out_output(out2[0], args))

        recon1 = [list(j) for j in set([tuple(i) for i in output_x])]
        return recon1


def out_output(out, args):
    output = []

    for i in range(len(out) // args.one_hot_len):
        slice_node = out[i * args.one_hot_len:(i + 1) * args.one_hot_len ]
        slice_node = list(slice_node)
        # print(max(slice_node))
        # print(slice_node.index(max(slice_node)))
        output.append((slice_node.index(max(slice_node))))
    return output

if __name__ == '__main__':

    data = [
        [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 2, 3, 4, 4, 4],
        [4, 4, 2, 4, 1, 4, 4, 4, 4, 4, 2, 4, 4, 4, 4, 2, 1, 4, 4, 4, 4],
        [4, 4, 2, 4, 4, 4, 4, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
        [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 1, 4, 4, 2, 4, 2, 4, 4, 4, 4, 4],
        [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 2, 4],
        [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
        [4, 4, 4, 4, 2, 4, 4, 2, 4, 4, 4, 4, 1, 4, 4, 1, 4, 4, 1, 4, 4],
    ]
    action = 3
    args = getArgs()
    source, data = getData(data, action)
    args.input_size = len(data[0])
    args.one_hot_len = action
    generator = wgan_div.Generator(args).to(device)
    discriminator = wgan_div.Discriminator(args).to(device)
    train(generator, discriminator, data, args)
    recon1 = inference(generator, data, args)
    getdata2file(recon1, 'wgan_div', 'tiger', 3, 3, 2)
