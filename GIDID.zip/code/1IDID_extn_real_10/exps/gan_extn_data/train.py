import os
import argparse
import random

import gan
import numpy as np
from torch.autograd import Variable
# import torch.nn.functional as F
import torch
from utils import *

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

cuda = True if torch.cuda.is_available() else False
Tensor = torch.cuda.FloatTensor if cuda else torch.FloatTensor


def getArgs():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_epochs", type=int, default=200, help="number of epoch of training")
    parser.add_argument("--batch_size", type=int, default=1, help="size of the batches")
    parser.add_argument("--lr", type=float, default=0.0002, help="adam: learning rate")
    parser.add_argument("--b1", type=float, default=0.5, help="adam: decay of first order momentum of gradient")
    parser.add_argument("--b2", type=float, default=0.999, help="adam: decay of first order momentum of gradient")
    parser.add_argument("--latent_dim", type=int, default=10, help="dimensionality of the latent space")
    parser.add_argument("--sample_interval", type=int, default=400, help="interval between data samples")
    args = parser.parse_args()
    return args


def getData(data=[], action=2):
    if data == []:
        with open('./data/tiger4_9.txt', 'r') as f:
            readlines = f.readlines()
        for line in readlines:
            data.append([int(i) for i in line.strip()])
    source = data
    new_data = []
    for item in data:
        tmp_item = []
        for i in item:  # i= 1,1,1,0,2,0,2
            tmp_i = [0] * action
            tmp_i[i] = 1
            tmp_item.extend(tmp_i)
        new_data.append(tmp_item)
    data = torch.tensor(new_data, dtype=torch.long)
    return source, data


def train(generator, discriminator, data, args):
    adversarial_loss = torch.nn.BCELoss().to(device)
    optimizer_G = torch.optim.Adam(generator.parameters(), lr=args.lr, betas=(args.b1, args.b2))
    optimizer_D = torch.optim.Adam(discriminator.parameters(), lr=args.lr, betas=(args.b1, args.b2))

    for epoch in range(args.n_epochs):
        for i, x in enumerate(data):

            # 
            valid = Variable(Tensor(1, 1).fill_(1.0), requires_grad=False)
            fake = Variable(Tensor(1, 1).fill_(0.0), requires_grad=False)

            real_res = Variable(torch.unsqueeze(x.type(Tensor), 0))

            # 训练生成器
            optimizer_G.zero_grad()
            z = Variable(Tensor(np.random.normal(0, 1, (args.batch_size, args.latent_dim))))
            gen_res = generator(z)

            d1 = discriminator(gen_res)
            g_loss = adversarial_loss(d1, valid)

            g_loss.backward()
            optimizer_G.step()

            # 训练辨别器
            optimizer_D.zero_grad()

            d2 = discriminator(real_res)
            d3 = discriminator(gen_res.detach())
            real_loss = adversarial_loss(d2, valid)
            fake_loss = adversarial_loss(d3, fake)

            d_loss = (real_loss + fake_loss) / 2
            d_loss.backward()
            optimizer_D.step()

            print("[Epoch %d/%d] [Batch %d/%d] [D loss: %f] [G loss: %f]"
                  % (epoch, args.n_epochs, i, len(data), d_loss.item(), g_loss.item()))


def inference(generator, data, args):
    output_x = []
    output_z = []
    with torch.no_grad():
        for i in range(200):
            # 生成随机数z,并把它放入到训练好的模型中用生成器生成
            z = torch.randn(args.batch_size, args.latent_dim).to(device)
            out2 = generator(z)
            output_x.append(out_output(out2[0], args))

        recon1 = [list(j) for j in set([tuple(i) for i in output_x])]
        return recon1

def out_output(out, args):
    output = []

    for i in range(len(out) // args.one_hot_len):
        slice_node = out[i * args.one_hot_len:(i + 1) * args.one_hot_len ]
        slice_node = list(slice_node)
        # print(max(slice_node))
        # print(slice_node.index(max(slice_node)))
        output.append((slice_node.index(max(slice_node))))
    return output

if __name__ == '__main__':
    data = [
        [2, 2, 0, 2, 2, 2, 2],
        [2, 2, 2, 1, 2, 2, 2],
        [0, 2, 2, 1, 2, 2, 0],
        [2, 2, 2, 2, 0, 0, 0],
        [2, 2, 2, 2, 2, 2, 0],
        [0, 2, 2, 2, 2, 2, 0],
        [2, 1, 2, 2, 2, 2, 2],
    ]
    action = 3
    args = getArgs()
    source, data = getData(data, action)
    args.input_size = len(data[0])
    args.one_hot_len = action
    generator = gan.Generator(args).to(device)
    discriminator = gan.Discriminator(args).to(device)
    train(generator, discriminator, data, args)
    recon1, recon2 = inference(generator, data, args)
    getdata2file(recon2, 'gan', 'tiger', 3, 3, 2)
